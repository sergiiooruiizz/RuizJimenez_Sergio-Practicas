package dominio;

public class Evento {
	
	
}
