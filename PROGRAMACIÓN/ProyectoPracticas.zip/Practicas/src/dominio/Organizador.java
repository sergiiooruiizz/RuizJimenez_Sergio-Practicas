package dominio;

public class Organizador {
	
	
}
