package servicio;

import java.util.Scanner;

import persistencia.CategoriaDao;

public class CategoriaServicio{
	private final Scanner sc;
	private CategoriaDao categoriaDao;
	
	public CategoriaServicio(Scanner sc) {
		this.sc = sc;
		this.categoriaDao = new CategoriaDao();
	}
}
