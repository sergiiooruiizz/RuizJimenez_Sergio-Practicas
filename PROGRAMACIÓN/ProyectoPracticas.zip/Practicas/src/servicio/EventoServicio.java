package servicio;

import java.util.Scanner;

import persistencia.CategoriaDao;
import persistencia.EventoDao;

public class EventoServicio{
	private final Scanner sc;
	private EventoDao eventoDao;
	private CategoriaDao categoriaDao;
	
	public EventoServicio(Scanner sc) {
		this.sc = sc;
		this.eventoDao = new EventoDao();
		this.categoriaDao = new CategoriaDao();
	}

}
