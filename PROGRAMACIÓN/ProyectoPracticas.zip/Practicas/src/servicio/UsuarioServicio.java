package servicio;

import java.util.Scanner;

import persistencia.UsuarioDao;

public class UsuarioServicio{
	private final Scanner sc;
	private UsuarioDao usuarioDao;
	
	public UsuarioServicio(Scanner sc) {
		this.sc = sc;
		this.usuarioDao = new UsuarioDao();
	}
	
}
