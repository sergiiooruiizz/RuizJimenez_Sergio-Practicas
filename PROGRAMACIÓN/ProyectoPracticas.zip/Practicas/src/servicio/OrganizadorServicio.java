package servicio;

import java.util.Scanner;

import persistencia.OrganizadorDao;

public class OrganizadorServicio{
	private final Scanner sc;
	private OrganizadorDao organizadorDao;
	
	public OrganizadorServicio(Scanner sc) {
		this.sc = sc;
		this.organizadorDao = new OrganizadorDao();
	}
	
}
