package dominio;

public class Organizador extends Usuario {
    private String telefono;

    public Organizador(String nombre, String correo, String constrasenia, String telefono) {
        super(nombre, correo, constrasenia);
        this.telefono = telefono;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}