package servicio;

import java.util.Scanner;
import dominio.Usuario;
import persistencia.UsuarioDao;

public class UsuarioServicio implements IUsuarioServicio {
    private final Scanner sc;
    private UsuarioDao usuarioDao;

    public UsuarioServicio(Scanner sc) {
        this.sc = sc;
        this.usuarioDao = new UsuarioDao();
    }

    @Override
    public Usuario hacerLogin() {
        System.out.println("\nIniciar sesion");
        System.out.print("Introduce tu nombre de usuario: ");
        String nombre = sc.nextLine();
        System.out.print("Introduce tu contraseña: ");
        String pass = sc.nextLine();

        Usuario user = usuarioDao.login(nombre, pass);

        if (user != null) {
            System.out.println("¡Bienvenido al sistema, " + user.getNombre() + "!");
            return user;
        } else {
            System.out.println("Error: El usuario o la contraseña no coinciden.");
            return null;
        }
    }

    @Override
    public void registrarUsuario() {
        System.out.println("\nRegistrar nuevo usuario");
        System.out.print("Nombre de usuario: ");
        String nombre = sc.nextLine();
        System.out.print("Correo electrónico: ");
        String correo = sc.nextLine();
        System.out.print("Contraseña: ");
        String pass = sc.nextLine();

        Usuario nuevoUsuario = new Usuario(nombre, correo, pass);
        
        boolean insertado = usuarioDao.registrar(nuevoUsuario);

        if (insertado) {
            System.out.println("Usuario '" + nombre + "' registrado correctamente.");
        } else {
            System.out.println("Error: Ya existe un usuario con ese nombre.");
        }
    }
}