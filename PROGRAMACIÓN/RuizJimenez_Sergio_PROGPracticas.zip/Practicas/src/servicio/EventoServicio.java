package servicio;

import java.util.Scanner;
import java.time.LocalDate;
import java.time.LocalTime;
import dominio.*;
import persistencia.*;
import util.Util;

public class EventoServicio implements IEventoServicio {
    private final Scanner sc;
    private EventoDao eventoDao;
    private CategoriaDao categoriaDao;

    public EventoServicio(Scanner sc) {
        this.sc = sc;
        this.eventoDao = new EventoDao();
        this.categoriaDao = new CategoriaDao();
    }

    @Override
    public void mostrarEventos() {
        for (Evento e : eventoDao.obtenerEventos().values()) {
            System.out.println("-> " + e.getNombre() + " (" + e.getFecha() + ")");
        }
    }

    @Override
    public void mostrarEventosUsuario(Usuario usuario) {
        for (Evento e : eventoDao.obtenerEventos().values()) {
            if (e.getAsistentes().contains(usuario)) {
                System.out.println("-> " + e.getNombre());
            }
        }
    }

    @Override
    public void inscribirUsuario(Usuario usuario) {
        System.out.print("Nombre del evento: ");
        String nombre = sc.nextLine();
        Evento e = eventoDao.obtenerEventos().get(nombre);
        if (e != null) { e.getAsistentes().add(usuario); System.out.println("Evento inscrito"); }
    }

    @Override
    public void cancelarInscripcion(Usuario usuario) {
        System.out.print("Nombre del evento: ");
        String nombre = sc.nextLine();
        Evento e = eventoDao.obtenerEventos().get(nombre);
        if (e != null) { e.getAsistentes().remove(usuario); System.out.println("Evento cancelado."); }
    }

    @Override
    public void mostrarEventosOrganizador(Organizador organizador) {
        for (Evento e : eventoDao.obtenerEventos().values()) {
            System.out.println("- Evento: " + e.getNombre());
        }
    }

    @Override
    public void crearEvento(Organizador organizador) {
        System.out.print("Título: "); String titulo = sc.nextLine();
        System.out.print("Descripción: "); String desc = sc.nextLine();
        int duracion = Util.pedirNumeroEntero(sc, "Duración: ");
        System.out.print("Ubicación: "); String ubi = sc.nextLine();
        System.out.print("Categoría: "); String catNombre = sc.nextLine();
        Categoria cat = categoriaDao.obtenerCategoria(catNombre);

        Evento nuevo = new Evento(titulo, desc, LocalDate.now(), LocalTime.now(), duracion, ubi, cat, organizador);
        eventoDao.insertarEvento(nuevo);
    }
}