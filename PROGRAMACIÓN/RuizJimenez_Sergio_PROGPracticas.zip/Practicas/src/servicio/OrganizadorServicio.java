package servicio;

import java.util.Scanner;
import dominio.Organizador;
import persistencia.OrganizadorDao;

public class OrganizadorServicio implements IOrganizadorServicio {
    private final Scanner sc;
    private OrganizadorDao organizadorDao;

    public OrganizadorServicio(Scanner sc) {
        this.sc = sc;
        this.organizadorDao = new OrganizadorDao();
    }

    @Override
    public Organizador hacerLogin() {
        System.out.println("\nLogear organizador");
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Contraseña: ");
        String pass = sc.nextLine();

        Organizador org = organizadorDao.login(nombre, pass);

        if (org != null) {
            return org;
        } else {
            System.out.println("Error: Las credenciales del organizador incorrectas.");
            return null;
        }
    }

    @Override
    public void registrarOrganizador() {
        System.out.println("\nRegistro de organizador");
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Correo: ");
        String correo = sc.nextLine();
        System.out.print("Contraseña: ");
        String pass = sc.nextLine();
        System.out.print("Teléfono: ");
        String tlf = sc.nextLine();

        Organizador nuevo = new Organizador(nombre, correo, pass, tlf);
        boolean exito = organizadorDao.registrar(nuevo);

        if (exito) {
            System.out.println("Organizador registrado correctamente.");
        } else {
            System.out.println("Error: Ese nombre ya está en uso.");
        }
    }
}